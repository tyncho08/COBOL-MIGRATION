gcc -I/usr/include/mysql -c cobmysqlapi3.c -o cobmysqlapi.o

