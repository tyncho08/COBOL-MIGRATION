gcc -I/usr/include/mysql -c cobmysqlapi.005.c
