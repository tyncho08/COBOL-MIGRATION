cobc -x presql2o.cbl cobmysqlapi.o -L/usr/lib64/mysql -lmysqlclient -lz
