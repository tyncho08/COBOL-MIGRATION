cobc -x presql2M.cbl cobmysqlapi.o -L/usr/lib64/mysql -lmysqlclient -lz
