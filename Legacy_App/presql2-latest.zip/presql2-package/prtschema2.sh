presql2 prtschema2.scb prtschema2.cbl
cobc -x prtschema2.cbl cobmysqlapi.o -L/usr/local/mysql/lib -lmysqlclient -lz
exit 0
