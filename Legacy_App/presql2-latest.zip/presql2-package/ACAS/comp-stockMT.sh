#presql2 stockMT.SCB stockMT.cbl
cobc -m stockMT.COB cobmysqlapi.o -L/usr/local/mysql/lib -lmysqlclient -lz

