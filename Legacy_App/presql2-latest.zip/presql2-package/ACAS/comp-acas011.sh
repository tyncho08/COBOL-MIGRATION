cobc -m acas011.COB cobmysqlapi.o -L/usr/local/mysql/lib -lmysqlclient -lz

