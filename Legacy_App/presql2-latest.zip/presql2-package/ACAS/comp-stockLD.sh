cobc -x stockLD.COB cobmysqlapi.o -L/usr/local/mysql/lib -lmysqlclient -lz


