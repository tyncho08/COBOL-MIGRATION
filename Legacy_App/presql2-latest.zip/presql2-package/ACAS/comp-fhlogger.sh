cobc -m fhlogger.COB cobmysqlapi.o -L/usr/local/mysql/lib -lmysqlclient -lz

